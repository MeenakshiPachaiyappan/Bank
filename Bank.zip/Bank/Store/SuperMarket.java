package Store;
import java.util.*;

public class SuperMarket {
	private String marketName;
	private int floorNumber, prodCount;
	private Product[] products;
	private int wallet = 0;
	SuperMarket(String marketName, int floorNumber, int prodCount){
	
		this.marketName = marketName;
		this.floorNumber = floorNumber;
		this.products =new  Product[prodCount];
	}
	
	void addProducts(Product product){
	
		for(int i = 0;i<this.products.length;i++){
			if(this.products[i]==null){
				this.products[i]=product;
				break;
			}
		}
	}
	
	int price(int buyItem, int prodQuantity){
		int price = 0;
		if(prodQuantity>products[buyItem-1].getQuantity()){
			System.out.println("out of stock");
		}
		
		else{
			Product obj = products[buyItem-1];
			price = obj.getRate()*prodQuantity;
			wallet = price+wallet;
			obj.reduceQuantity(prodQuantity);
		}
		return price;
	}
	
	public int getWallet(){
		return wallet;
	}
	
	public void setWallet(int wallet){
		this.wallet = wallet;
	}
	
	void display(){
		Product products[] = this.products;
		
		for(int i =0;i<products.length;i++){
			products[i].display();
		}
	}
}
