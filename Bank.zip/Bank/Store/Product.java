package Store;

public class Product {
	
				private String prodName;
				private int quantity,rate;
				
				public String getProdName(){
					return prodName;
				}
				
				public void setName(String prodName){
					this.prodName = prodName;
				}
				
				public int getQuantity(){
					return quantity;
				}
			
				public void setQuantity(int quantity){
					this.quantity=quantity;
				}
			
			
				public int getRate(){
					return rate;
				}
			
				public void setRate(int rate){
					this.rate=rate;
				}
				
				Product(String prodName, int quantity, int rate){
				
					this.prodName = prodName;
					this.quantity = quantity;
					this.rate = rate;
				}
				
				void display(){
					
					System.out.println("Details of the products-->" + prodName + "- "+ "quantity:" +quantity +" "+"rate"+ rate);
				}
				
				public void reduceQuantity(int total){
					this.quantity = this.quantity- total;
				}

}
