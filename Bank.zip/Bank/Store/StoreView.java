package Store;
import java.util.*;
public class StoreView {
	public static void main(String args[]){
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the supermarket name:");
		String marketName = scanner.nextLine();
		System.out.println("enter the floor number:");
		int floorNumber = scanner.nextInt();
		System.out.println("enter the number of products to be added:");
		int prodCount = scanner.nextInt();
		
		SuperMarket supermarket = new SuperMarket(marketName, floorNumber, prodCount);
		
		for(int i = 0;i<prodCount; i++){
		
			Scanner scanner1 = new Scanner(System.in);
			System.out.println("enter the product details:");
			System.out.println("enter the product name:");
			String prodName = scanner1.nextLine();
			System.out.println("enter the quantity of the product:");
			int quantity = scanner1.nextInt();
			System.out.println("enter the rate of the product:");
			int rate = scanner1.nextInt();
			
			Product product = new Product(prodName,quantity,rate);
			supermarket.addProducts(product);
		}
		int option = 0;
		do{
			System.out.println("Choose any one option 1.Display 2.Buy 3.Show wallet 4.Exit the supermarket");
			Scanner scanner2 = new Scanner(System.in);
			 option = scanner.nextInt();
			
			switch(option){
				case 1:
				supermarket.display();
				break;
				
				case 2:
				System.out.println("what do u want to buy?");
				int buyItem = scanner.nextInt();
				
				if(buyItem>prodCount){
					System.out.println("the product is not available.");
				}
				
				else{
					System.out.println("enter the quantity that u want to buy:");
					int prodQuantity = scanner2.nextInt();
					System.out.println("the rate is :"+ supermarket.price(buyItem,prodQuantity));
				}
				break;
				
				case 3:
				System.out.println("the amount in the wallet is:"+supermarket.getWallet());
				break;
				
				case 4:
				System.out.println("Thank you for visiting");
				break;
				
				default:
				System.out.println("enter a valid option.");
				break;
			}
		}
		while(option<4);
	}

}